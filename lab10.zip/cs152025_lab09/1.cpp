#include<iostream>
#include<unistd.h>
#include<stdlib.h>
using namespace std;
int main()
{
    int pid=fork();
    char *cmd[]={"ps","aux",NULL};
    if(pid<0)
    {
    exit(0);
    }
    else if(pid>0)
    {
        cout<<endl<<"****I am Parent Process**** "<<endl<<endl;
        cout<<"************Forking Child Process**********"<<endl<<endl;
        while(1){}
    }

    // As parent porcess start subtasking and child process start executing

    else
    {
      int gchild=fork();

        //zombie porcess
          
        if(gchild>0)
        {
        }

        //Orphan Process

        else
        {
            usleep(500000);
            cout<<"******I am Orphan as well as Zombie process having ParentID: "<<getppid()<<" ******"<<endl<<endl;
            usleep(500000);
            execvp("/bin/ps",cmd);
        }
}
return 0;
}

