echo Insert number
read x

while [ $x != 0 ]
do
	num=`expr $x % 10`
	x=`expr $x / 10`
	sum=`expr $sum + $num`
done

for (( i=1; i<sum; i++ ))
do
	po=`expr $i \* $i`
	if [ po -eq sum ]
		do
			echo "Yes, sum is $sum which is perfect square of $i"
	fi
done
