echo Eneter a number
read x
num=1

for (( i=1; i<=x; i++ ))
do
	
	for (( j=1; j<x; j++ ))
	do
	num=`expr $num + $x`
		 echo -n "$num "

	done
	num=`expr $num + 1`
	echo " "
done
