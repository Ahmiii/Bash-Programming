echo Enter a imputs
read x
read y

for (( i=0; i<x; i++ ))
do
	if [ `expr $x % $4 -eq 0` ]
	do
		echo "hcf is $x "
done 


