
i=0
x=0

echo "************Max prcess to enter are 5***************"
echo "Enter the number of process Max: "
read n
wt[0]=$SECONDS   # first process wait time
bt[0]=3 # first porcess burst time
tat[0]3 #first process turnaround time
for(( i=0;i<n;i++))
do
    echo "Enter bash File: "
    read x
    readyq[$i]=$x
    sleep 2   
done



# burst time time of each porcess are
for((i=1;i<n;i++))
do
    echo "Enter burst time"
    read x
    bt[$i]=$x
done

#wait time of each process


for((i=1;i<n;i++))
do
    sleep 2
    wt[$i]=`expr $wt[`expr $i - 1`] + $bt[`expr $i - 1`]`  
done        

#trunaround time

for((i=1;i<n;i++))
do
    tat[$i]=`expr $wt[i] + $bt[i]`
done

# average wt
for((i=0;i<n;i++))
do
    avgw=`expr $avg + $wt[$i]` 
done
avgw=`expr $avg / 2`

#avg tat
for((i=0;i<n;i++))
do
    avgt=`expr $avg + $tat[$i]` 
done
avgt=`expr $avg / 2`


#print table of process


for((i=0;i<n;i++))
do
    echo $wt[$i] " " $bt[$i] " " $tat[$i]
    echo "-n"
done 
echo $avgw " " $avgt






