i=0
x=0

echo "************Max prcess to enter are 5***************"
echo "Enter the number of process Max: "
read n
wt[0]=0 # first process wait time
bt[0]=3 # first porcess burst time
tat[0]3 #first process turnaround time
for(( i=0;i<n;i++))
do
    echo "Enter bash File: "
    read x
    readyq[$i]=$x
    sleep 2   
done
