#include<iostream>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
#define numth 5
using namespace std;

int a[5];  //globl array of size 5

//thread
void *adding(void *arg)
{   
    
    int *b=(int *)arg;
     for(int i=0;i<5;i++)
    {
        a[i]=*b;
    }
 
}


int main()
{

//input in main array 
    int d[5];
    for(int i=0;i<5;i++)
    {
        cin>>d[i];
    }

//creating thread id's
    pthread_t tids[numth];
    for(int i=0;i<numth;i++)
    {
        //creating multiple threads
        pthread_attr_t attr;   
        pthread_attr_init(&attr);
        pthread_create(&tids[i], NULL, adding, (void *)(&d[i])); //assigning values in thread from arrays
    }
   
//  join each threads
    for(int i=0;i<numth;i++)
    {
        pthread_join(tids[i],NULL);
    }
    //output result
    for(int i=0;i<5;i++)
    {
            cout<<a[i]<<endl;
    }


}
