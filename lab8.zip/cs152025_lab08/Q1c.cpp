#include<iostream>
#include<unistd.h>
#include<stdlib.h>
using namespace std;

void fn()
{
    if(fork()==0)
    {
        fork();
        cout<<"Hello"<<endl;
    }
}

int main()
{
    fn();
    cout<<"HELLO"<<endl;
    exit(0);
}
