#include<iostream>
#include<unistd.h>
#include<stdlib.h>
#include<sys/wait.h>
using namespace std;

int main()
{
    int counter=1;
    if(fork()==0)
    {
        counter--;
        exit(0);
    }
    else
    {
        wait(NULL);
        counter++;
        cout<<"Counter = "<<counter<<endl;

    }
        exit(0);

}
