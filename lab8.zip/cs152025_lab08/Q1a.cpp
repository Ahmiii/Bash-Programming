#include<iostream>
#include<unistd.h>
#include<stdlib.h>
using namespace std;
void fn()
{
    fork();
    fork();
    fork();
    cout<<"HELLO"<<endl;
}

int main()
{
    fn();
    cout<<"Hello"<<endl;
    exit(0);
}
