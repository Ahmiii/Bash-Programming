#include<iostream>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<string.h>
#include<sys/ipc.h>
using namespace std;
int main()
{
      int shmid;
      char *shm;
        key_t key;
        key=9876;

    shmid=shmget(key,100,0666|IPC_CREAT);
    shm=(char *)shmat(shmid,0,0);
    
    if(shmid<0)
    {
        cout<<"ERROR"<<endl;
    }
    else
    {
        memcpy(shm,"0123456789ABCD*",15);
        int count=1,i=0;
         while(shm[i]!='*')
        {
            if((shm[i]>='1' && shm[i]<='9'))
            {
                count++;
            }
            i++;
        }            
      cout<<"Total Number of Digits: "<<count<<endl;  
     }
    
}

