#include<iostream>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
using namespace std;

int main()
{
    int pip[2],pips[2],pip3[2];
    pid_t id,cd;
    char fixbuffer[80];
    char fixbuffers[80];
    pipe(pip);
    pipe(pips);
    pipe(pip3);
    if((id=fork())==-1)
        {
       //     cout<<"Error";
        }
    if(id==0)
        {
                ////////// Process P2 //////////
                    
                        //receive message//

            close(pip[1]);               // close write side of a pipe
            read(pip[0],fixbuffer,sizeof(fixbuffer));
            close(pip[0]);              // close read side of pipe
            cout<<"P1 to P2: "<<fixbuffer<<endl;

                        //send message//
            
            close(pips[0]);
            write(pips[1],"Loud And Clear",14);
            close(pips[1]);

                    //receive message//

            close(pip3[1]);               // close write side of a pipe
            read(pip3[0],fixbuffers,sizeof(fixbuffers));
            close(pip3[0]);              // close read side of pipe
            cout<<"P1 to P2: "<<fixbuffers<<endl;

            exit(0);

        }                     
            
            
    else
        {
                ////////// Process 1 //////////
    
                    //send message
            
            close(pip[0]); // close read side of pipe
            write (pip[1],"Are You Hearing Me",20);
            close(pip[1]);  //close write side of pipe
           
            
                        //receive message//

            close(pips[1]);
            read(pips[0], fixbuffer,sizeof(fixbuffer));
            close(pips[0]); //close read side
            cout<<"P2 to P1: "<<fixbuffer<<endl;

                       //send message//
          
            close(pip3[0]);
            write(pip3[1],"I can hear you",14);
            close(pip3[1]);    
                        
    
                         

}
    }
    
    
