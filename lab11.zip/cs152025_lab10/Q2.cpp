#include<iostream>
#include<unistd.h>
#include<stdlib.h>
#include<sys/shm.h>
#include<sys/types.h>
#include<sys/wait.h>
using namespace std;

int main()
{
    int shmid;
    shmid=shmget(IPC_PRIVATE,4,0666|IPC_CREAT);
    cout<<shmid<<endl;
}
