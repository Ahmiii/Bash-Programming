File=`zenity --entry`
save=`zenity --file-selection --filename="$File"`
vi $File   

