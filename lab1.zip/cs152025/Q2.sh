echo Enter a databse name
read x

File=`zenity --entry`
getent $File  > /dev/null x
if [ $File == x ];
then	
	echo "user exits"
else
	echo "no "
fi
