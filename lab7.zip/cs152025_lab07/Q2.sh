echo "Enter Cycles"
sleep 10
echo "process sleep for 10 second"
read x
for (( i=0; i<$x; i++ ))
    do
        echo "Hello"
        if (( $i % 2 == 0 ))
            then
                echo "Want to end a Process Press y"
                read input
                if (( $input == "y" ))
                    then
                        killall -e bash Q2
                    else
                        echo "Process is running"
                 fi
        fi
    done

                    
