fibo()

{
if (( $1 == 0 ))
then
	echo 0
elif (( $1 == 1 ))
then
	echo 1
else
    i=`expr $1 - 1`
    j=`expr $1 - 2`
    k=`fibo $i`
    l=`fibo $j`
    echo $((k+l))
    
fi
}
    echo "Enter a number"
    read x
    echo "Fibbonachhi $x number is" $(fibo $x)
